Array.from(document.querySelectorAll("*[data-include]")).map(async (v, i) => {
  const include = v.dataset.include;
  let html = null;

  try {
    const response = await axios.get(include);
    html = response.data;
  } catch (e) {
    console.error(e);
  }

  if (html != null) {
    v.outerHTML = html;
  }

  //   if (include.indexOf("header.html") > -1) {
  //     document.querySelector(".bottom").addEventListener("mouseover", (e) => {
  //       const current = e.currentTarget;
  //       const sub = current.querySelector("#hidden");
  //       sub.style.maxHeight = sub.scrollHeight + "px";
  //     });

  //     document.querySelector(".bottom").addEventListener("mouseout", (e) => {
  //         const current = e.currentTarget;
  //         const sub = current.querySelector("#hidden");
  //         // scrollHeight는 요소의 크기를 벗어난 만큼의 높이를 의미
  //         sub.style.maxHeight = null;
  //       });
  //   }

  //   if (include.indexOf("header.html") > -1) {
  //       const submenu = document.querySelector('#sub_menu1');
  //       document.querySelector('.bottom').addEventListener('click', (e) => {
  //           submenu.classList.toggle('hidden');
  //       });
  //   }

  if (include.indexOf("header.html") > -1) {
      document.querySelectorAll('.bottom').forEach((v, i) =>{
        v.addEventListener('click', (e) => {
            const sub = document.querySelector('.sub_menu');
            sub.classList.toggle('hidden');
        });
      });
  }
});
